/* 
PRG001 Practical week 6
Name: Tran Nguyen Thanh Truc - Katherine
Student's ID: 43557
*/

/* 1. Birthday
var birthday = prompt ("Is today your birthday?");
if (birthday == "yes"); {
  var username = prompt ("Please enter your name");
  document.write ("Happy birthday to you." + "<br>" + "Happy birthday to you." + "<br>" +  "Happy birthday dear " + username + "!" + "<br>" + "Happy birthday to you.");
} */

/* 2. Numbers 
var num1 = prompt ("Please enter the first number.");
var num2 = prompt ("Please enter the second number.");
 if (num1 < num2) {
  document.write ("First number: " + num1 + "<br>" + "Second number: " + num2 + "<br>");
  document.write ("Second number is larger");
 } else {
  document.write ("First number: " + num1 + "<br>" + "Second number: " + num2 + "<br>");
  document.write ("Second number is smaller");
 }*/

  /*3. Odd or even
 var num = prompt ("Please enter a number.");
  if (num % 2 == 1) {
   alert ("The number is odd.");
} else {
   alert ("The number is even.");
}*/

/*4. Mark
var mark = prompt ("Please enter a mark.")
 if (mark < 60) {
  document.write ("Your grade is: F");
 } else if (mark < 70) {
  document.write ("Your grade is: D");
} else if (mark < 80) {
  document.write ("Your grade is: C");
} else if (mark < 90) {
  document.write ("Your grade is: B")
} else {
  document.write ("Your grade is: A");
}*/

//5. Dice game
var dice1 = Math.floor ((Math.random() * 6) + 1);
var dice2 = Math.floor ((Math.random() * 6) + 1);
var dice3 = Math.floor ((Math.random() * 6) + 1);
 document.write = ("Dice 1: " + dice1);
 document.write = ("Dice 2: " + dice2);
 document.write = ("Dice 3: " + dice3);
 if (dice1 == dice2 && dice2 == dice3) {
  document.write ("3 of a kind"); 
  } else if (dice1 == dice2 || dice2 == dice3 || dice1 == dice3) {
    document.write ("2 of a kind");
 } else {
  document.write ("No matches");
 }


 

